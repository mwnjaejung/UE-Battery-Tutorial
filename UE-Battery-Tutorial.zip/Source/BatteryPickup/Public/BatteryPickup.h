// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#ifndef __BATTERYPICKUP_H__
#define __BATTERYPICKUP_H__

#include "EngineMinimal.h"

#endif
