// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "BatteryPickup.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BatteryPickup, "BatteryPickup" );
 